README. File

InfoSec Chatbot Description
The Infosechatbot is a basic chatbot designed to give you information on the various different social engineering tactics used to scam people
as well guides and quizzes on how to understand information security as a whole by giving you basic definitions on security topics
that will help inform you in the world of IT security.


How to start quiz: 
type in "start quiz" to begin the quiz.
IMPORTANT NOTICE
when answering the quiz make sure you answer like this " answer 1 " or " answer 2 " inorder for you input to be validated.

How to use Task Assistance:
type in "assist with " followed by what you want it to assist you with.
Task assistance bot is limited to assisting with "passwords, phishing and safe browsing" nothing else.

How to Add, Complete and Delete Tasks:
type in "add task " followed by whatever task you want added to add a task.
type in "complete task " followed by what task you added that you want shown completed
type in "delete task " followed by what task you added that you want deleted

How to use Log Feature
simply type "show log" and a record of everything you've asked, added, deleted and completed should appear

HOW TO RUN CODE
use "Visual Studio" not VS code



