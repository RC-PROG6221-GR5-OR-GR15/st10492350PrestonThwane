﻿using System;
using System.Collections.Generic;

namespace InfoSecChatBot
{
    internal class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime? Reminder { get; set; }

        public TaskItem(string description)
        {
            Title = string.Empty; // or any default value you want
            Description = description;
            IsCompleted = false;
            Reminder = null;
        }
    }

    internal class LogEntry
    {
        public DateTime Timestamp { get; set; }
        public string UserInput { get; set; }
        public string BotResponse { get; set; }

        public LogEntry(string userInput, string botResponse)
        {
            Timestamp = DateTime.Now;
            UserInput = userInput;
            BotResponse = botResponse;
        }
    }

    internal class DataHandler
    {
        private List<TaskItem> tasks = new List<TaskItem>();
        private List<string> storedNames = new List<string>();
        private List<string> storedTopics = new List<string>();
        private List<LogEntry> activityLog = new List<LogEntry>();

        // Save a user name
        public void SaveName(string name) => storedNames.Add(name);
        public List<string> GetNames() => storedNames;

        // Save a favourite topic
        public void SaveTopic(string topic) => storedTopics.Add(topic);
        public List<string> GetTopics() => storedTopics;

        // Task management
        public void AddTask(string description, DateTime? reminder = null) =>
            tasks.Add(new TaskItem(description) { Reminder = reminder });

        public List<TaskItem> GetTasks() => tasks;

        public bool CompleteTask(string description)
        {
            var task = tasks.Find(t => t.Description.Equals(description, StringComparison.OrdinalIgnoreCase));
            if (task != null) { task.IsCompleted = true; return true; }
            return false;
        }

        public bool DeleteTask(string description)
        {
            var task = tasks.Find(t => t.Description.Equals(description, StringComparison.OrdinalIgnoreCase));
            if (task != null) { tasks.Remove(task); return true; }
            return false;
        }

        // Activity log
        public void LogInteraction(string userInput, string botResponse) =>
            activityLog.Add(new LogEntry(userInput, botResponse));

        public List<LogEntry> GetActivityLog() => activityLog;
    }
}
