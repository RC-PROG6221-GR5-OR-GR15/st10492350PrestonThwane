using System;
using System.Linq;

namespace InfoSecChatBot
{
    class GetResponse
    {
        private static string lastTopic = "";
        private static string userName = "";
        private static string favouriteTopic = "";
        private static string lastSentiment = "";
        private static int currentQuestionIndex = -1;
        private static int score = 0;

        private static (string Question, string[] Options, int CorrectIndex)[] quizQuestions =
        {
    ("What does 2FA stand for?", new[] { "Two-Factor Authentication", "Two-Firewall Access", "Two-File Agreement" }, 0),
    ("Which of these is a phishing sign?", new[] { "Urgent request for login", "Correct spelling and grammar", "Official company domain" }, 0),
    ("What is ransomware?", new[] { "Malware demanding payment", "A firewall type", "An encryption method" }, 0),
    ("Best practice for passwords?", new[] { "Use unique, complex ones", "Reuse across accounts", "Keep them short" }, 0)
};


        // Hook in DataHandler
        private static DataHandler dataHandler = new DataHandler();

        public static string GetResponseMessage(string input)
        {
            input = input.ToLower().Trim(new char[] { '.', '?', '!' });

            string response = null;

            // Sentiment Detection Section
            if (input.Contains("sad") || input.Contains("upset") || input.Contains("angry") || input.Contains("frustrated") || input.Contains("deperessed"))
            {
                lastSentiment = "negative";
                response = $"I'm sorry to hear that, {userName}. Cybersecurity can be stressful sometimes.";
            }
            else if (input.Contains("happy") || input.Contains("great") || input.Contains("good") || input.Contains("excited") || input.Contains("joyful"))
            {
                lastSentiment = "positive";
                response = $"That’s wonderful to hear, {userName}! Keeping a positive mindset helps you stay alert and safe online.";
            }
            else if (input.Contains("ok") || input.Contains("fine") || input.Contains("neutral"))
            {
                lastSentiment = "neutral";
                response = $"Got it, {userName}. Let’s keep learning about cybersecurity together.";
            }
            // Conversational Flow Section
            else if (input.Contains("tell me more") || input.Contains("explain more") || input.Contains("give another tip"))
            {
                if (string.IsNullOrEmpty(lastTopic))
                    response = "We haven’t discussed a topic yet. Ask me about something like phishing or password safety!";
                else
                    response = ElaborateOnTopic(lastTopic);
            }
            // Memory and Recall Section
            else if (input.StartsWith("my name is"))
            {
                userName = input.Replace("my name is", "").Trim();
                dataHandler.SaveName(userName);
                response = $"Nice to meet you, {userName}! I’ll remember your name for our chat.";
            }
            else if (input.StartsWith("my favourite topic is"))
            {
                favouriteTopic = input.Replace("my favourite topic is", "").Trim();
                dataHandler.SaveTopic(favouriteTopic);
                response = $"Got it! I’ll remember that your favourite topic is {favouriteTopic}.";
            }
            else if (input.Contains("what is my name"))
            {
                var names = dataHandler.GetNames();
                if (names.Count == 0)
                    response = "I don’t think you’ve told me your name yet.";
                else
                    response = $"Your name is {names.Last()}.";
            }
            else if (input.Contains("what is my favourite topic"))
            {
                var topics = dataHandler.GetTopics();
                if (topics.Count == 0)
                    response = "You haven’t mentioned your favourite topic yet.";
                else
                    response = $"Your favourite topic is {topics.Last()}.";
            }
            // --- Task Commands ---
            else if (input.StartsWith("add task"))
            {
                string taskDesc = input.Replace("add task", "").Trim();
                dataHandler.AddTask(taskDesc);
                response = $"Task '{taskDesc}' added!";
            }
            else if (input.Contains("show tasks"))
            {
                var tasks = dataHandler.GetTasks();
                if (tasks.Count == 0)
                    response = "No tasks stored.";
                else
                    response = string.Join(Environment.NewLine, tasks.Select(t =>
                        $"{t.Description} - {(t.IsCompleted ? "Completed" : "Pending")}" +
                        (t.Reminder.HasValue ? $" (Reminder: {t.Reminder.Value})" : "")
                    ));
            }
            else if (input.StartsWith("complete task"))
            {
                string taskDesc = input.Replace("complete task", "").Trim();
                bool success = dataHandler.CompleteTask(taskDesc);
                response = success ? $"Task '{taskDesc}' marked as completed." : $"Task '{taskDesc}' not found.";
            }
            else if (input.StartsWith("delete task"))
            {
                string taskDesc = input.Replace("delete task", "").Trim();
                bool success = dataHandler.DeleteTask(taskDesc);
                response = success ? $"Task '{taskDesc}' deleted." : $"Task '{taskDesc}' not found.";
            }
            else if (input.StartsWith("assist with"))
            {
                string topic = input.Replace("assist with", "").Trim();

                switch (topic)
                {
                    case "passwords":
                        response = "Here’s how to create strong passwords:\n" +
                                   "1. Use at least 12 characters.\n" +
                                   "2. Mix uppercase, lowercase, numbers, and symbols.\n" +
                                   "3. Avoid personal info (like birthdays).\n" +
                                   "4. Use a password manager to keep track.";
                        break;

                    case "phishing":
                        response = "Steps to protect against phishing:\n" +
                                   "1. Check sender email carefully.\n" +
                                   "2. Hover over links before clicking.\n" +
                                   "3. Don’t download unexpected attachments.\n" +
                                   "4. Report suspicious emails to IT/security.";
                        break;

                    case "safe browsing":
                        response = "Safe browsing checklist:\n" +
                                   "1. Keep your browser updated.\n" +
                                   "2. Use HTTPS websites only.\n" +
                                   "3. Avoid clicking pop‑ups.\n" +
                                   "4. Install reputable security extensions.";
                        break;
                    case "Malware":
                        response = "To protect against malware:\n" +
                                   "1. Install and update antivirus software.\n" +
                                   "2. Avoid downloading from untrusted sources.\n" +
                                   "3. Keep your operating system and apps updated.\n" +
                                   "4. Be cautious with email attachments.";
                        break;
                    case "firewall":
                        response = "To effectively use a firewall:\n" +
                                   "1. Enable your operating system's built-in firewall.\n" +
                                   "2. Configure rules to block unwanted traffic.\n" +
                                   "3. Regularly review firewall logs for suspicious activity.\n" +
                                   "4. Consider using a hardware firewall for added security.";
                        break;
                     case "encryption":
                        response = "To implement encryption:\n" +
                                   "1. Use strong encryption algorithms (like AES-256).\n" +
                                   "2. Encrypt sensitive files and communications.\n" +
                                   "3. Use encrypted connections (HTTPS, VPNs).\n" +
                                   "4. Regularly update encryption keys and certificates.";
                        break;
                     case "social engineering":
                            response = "To defend against social engineering:\n" +
                                       "1. Be skeptical of unsolicited requests for information.\n" +
                                       "2. Verify identities before sharing sensitive data.\n" +
                                       "3. Educate yourself and others about common social engineering tactics.\n" +
                                       "4. Report any suspicious interactions to your security team.";
                        break;
                     case "ddos":
                        response = "To mitigate DDoS attacks:\n" +
                                   "1. Use a content delivery network (CDN) to distribute traffic.\n" +
                                   "2. Implement rate limiting and traffic filtering.\n" +
                                   "3. Monitor network traffic for unusual spikes.\n" +
                                   "4. Have a DDoS response plan in place.";
                        break;
                     case "cybersecurity":
                        response = "To enhance cybersecurity:\n" +
                                   "1. Keep software and systems updated.\n" +
                                   "2. Use strong, unique passwords and enable 2FA.\n" +
                                   "3. Regularly back up important data.\n" +
                                   "4. Educate yourself and your team about security best practices.";
                        break;
                      case "vulnerability":
                        response = "To manage vulnerabilities:\n" +
                                   "1. Regularly scan systems for vulnerabilities.\n" +
                                   "2. Apply patches and updates promptly.\n" +
                                   "3. Prioritize fixing critical vulnerabilities first.\n" +
                                   "4. Conduct regular security assessments.";
                        break;

                    default:
                        response = $"I don’t have an assistant guide for '{topic}' yet. Try 'assist with passwords', 'assist with phishing', or 'assist with safe browsing'.";
                        break;
                }
            }
            else if (input.Contains("start quiz"))
            {
                currentQuestionIndex = 0;
                score = 0;
                var q = quizQuestions[currentQuestionIndex];
                response = $"Quiz started!\nQ1: {q.Question}\nOptions:\n1. {q.Options[0]}\n2. {q.Options[1]}\n3. {q.Options[2]}";
            }
            else if (input.StartsWith("answer"))
            {
                if (currentQuestionIndex == -1)
                {
                    response = "You haven’t started a quiz yet. Type 'start quiz' to begin.";
                }
                else
                {
                    int userChoice;
                    if (int.TryParse(input.Replace("answer", "").Trim(), out userChoice))
                    {
                        var q = quizQuestions[currentQuestionIndex];
                        if (userChoice - 1 == q.CorrectIndex)
                        {
                            score++;
                            response = "Correct!";
                        }
                        else
                        {
                            response = $"Incorrect. The correct answer was: {q.Options[q.CorrectIndex]}";
                        }

                        currentQuestionIndex++;
                        if (currentQuestionIndex < quizQuestions.Length)
                        {
                            var nextQ = quizQuestions[currentQuestionIndex];
                            response += $"\n\nQ{currentQuestionIndex + 1}: {nextQ.Question}\nOptions:\n1. {nextQ.Options[0]}\n2. {nextQ.Options[1]}\n3. {nextQ.Options[2]}";
                        }
                        else
                        {
                            response += $"\n\nQuiz finished! Your score: {score}/{quizQuestions.Length}";
                            currentQuestionIndex = -1;
                        }
                    }
                    else
                    {
                        response = "Please answer with a number (1, 2, or 3).";
                    }
                }
            }

            // Activity log commands
            else if (input.Contains("show log"))
            {
                var log = dataHandler.GetActivityLog();
                response = log.Count == 0 ? "No activity recorded yet." :
                    string.Join(Environment.NewLine, log.Select(l =>
                        $"{l.Timestamp}: You said '{l.UserInput}', Cynthia replied '{l.BotResponse}'"
                    ));
            }
            // --- InfoSec responses ---
            else if (input.Contains("password"))
            {
                lastTopic = "password";
                response = "Make sure to use strong, unique passwords for each account. Avoid using personal details in your passwords.";
            }
            else if (input.Contains("scam"))
            {
                lastTopic = "scam";
                response = "Be cautious of unsolicited messages or links. Verify sources before sharing information to avoid scams.";
            }
            else if (input.Contains("privacy"))
            {
                lastTopic = "privacy";
                response = "Protect your privacy by limiting what you share online and reviewing app permissions regularly.";
            }
            else if (input.Contains("phishing"))
            {
                lastTopic = "phishing";
                response = "Phishing is a cyber attack where attackers trick users into revealing sensitive info.";
            }
            else if (input.Contains("encryption"))
                response = "Encryption is the process of converting data into a coded format to prevent unauthorized access.";
            else if (input.Contains("firewall"))
                response = "A firewall is a network security device that monitors and controls incoming and outgoing network traffic.";
            else if (input.Contains("malware"))
                response = "Malware is malicious software designed to harm, exploit, or otherwise compromise a computer system.";
            else if (input.Contains("ransomware"))
                response = "Ransomware is a type of malware that encrypts a victim's files and demands payment for the decryption key.";
            else if (input.Contains("social engineering"))
                response = "Social engineering is a manipulation technique that exploits human error to gain private information.";
            else if (input.Contains("ddos"))
                response = "DDoS (Distributed Denial of Service) is an attack where multiple compromised systems flood a target with traffic.";
            else if (input.Contains("cybersecurity"))
                response = "Cybersecurity is the practice of protecting systems, networks, and data from digital attacks.";
            else if (input.Contains("how are you") || input.Contains("how are you doing"))
                response = "I'm doing well and feeling secure, thank you for asking! How can I assist you with Information Security topics today?";
            else if (input.Contains("what is your name") || input.Contains("who are you"))
                response = "My name is Cynthia, and I'm a Bot here to help you with Information Security topics. What would you like to know?";
            else if (input.Contains("what can you do") || input.Contains("what are your capabilities"))
                response = "I can provide information on various Information Security topics such as phishing, encryption, firewalls, malware, and more. Just ask me about any topic you're interested in!";
            else if (input.Contains("cyber hygiene"))
                response = "Cyber hygiene refers to the practices and steps that users of computers and other devices take to maintain system health and improve online security.";
            else if (input.Contains("threat intelligence"))
                response = "Threat intelligence is the information that organizations use to understand the threats that have, will, or are currently targeting them.";
            else if (input.Contains("what is your purpose") || input.Contains("what is your mission"))
                response = "My purpose is to provide information and answer questions about Information Security topics to help users understand and improve their cybersecurity knowledge.";
            else if (input.Contains("password management"))
                response = "Password management involves creating, storing, and using strong passwords to protect accounts and sensitive information.";
            else if (input.Contains("safe browsing"))
                response = "Safe browsing is the practice of using the internet in a way that minimizes the risk of encountering malicious websites and content.";
            else if (input.Contains("data privacy"))
                response = "Data privacy is the aspect of information technology that deals with the ability of an individual or organization to control how their personal information is collected and used.";
            else if (input.Contains("why is the sky blue"))
                response = "The sky appears blue due to the scattering of sunlight by the Earth's atmosphere, which is more effective at scattering shorter wavelengths of light (blue) than longer wavelengths (red).";
            else if (input.Contains("what is information security") || input.Contains("what is infosec"))
                response = "Information security, often abbreviated as InfoSec, is the practice of protecting information by mitigating information risks and vulnerabilities.";
            else if (input.Contains("vulnerability"))
                response = "A vulnerability is a weakness in a system that can be exploited by attackers to gain unauthorized access.";
            else if (input.Contains("patching"))
                response = "Patching is the process of applying updates to software to fix vulnerabilities and improve security.";
            else if (input.Contains("two-factor authentication") || input.Contains("2fa"))
                response = "Two-factor authentication (2FA) adds an extra layer of security by requiring two forms of verification.";
            else if (input.Contains("zero-day"))
                response = "A zero-day vulnerability is a security flaw that is unknown to the software vendor and can be exploited by attackers.";
            else if (input.Contains("penetration testing") || input.Contains("pentesting"))
                response = "Penetration testing is a simulated cyber attack against a system to identify vulnerabilities.";
            else if (input.Contains("security awareness training"))
                response = "Security awareness training educates employees about cybersecurity best practices and how to recognize and respond to potential security threats.";
            else
                response = "I'm sorry, I didn't understand that. Could you please rephrase or ask about an Information Security topic?";

            // ✅ Log every interaction
            dataHandler.LogInteraction(input, response);

            return response;
        }


        private static string ElaborateOnTopic(string topic)
        {
            // You can expand this logic as needed
            switch (topic)
            {
                case "password":
                    return "A strong password should include a mix of letters, numbers, and special characters. Consider using a password manager to keep track of your passwords.";
                case "scam":
                    return "Scams often use urgency or fear to trick you. Always double-check the sender and never share personal information with unverified sources.";
                case "privacy":
                    return "Regularly review your privacy settings on social media and other online accounts to control what information you share.";
                case "phishing":
                    return "Phishing emails often look legitimate. Check for spelling mistakes, suspicious links, and always verify the sender's address.";
                default:
                    return "I can provide more details if you specify a topic like password, scam, privacy, or phishing.";
            }
        }
    }
}